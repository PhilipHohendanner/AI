package at.jku.cp.ai.search.algorithms;

import java.util.function.Predicate;

import at.jku.cp.ai.search.Node;
import at.jku.cp.ai.search.Search;


// Breadth-First search
public class BFS implements Search
{
	@Override
	public Node search(Node start, Predicate<Node> endPredicate)
	{
		// TODO, assignment 1
		return null;
	}
}