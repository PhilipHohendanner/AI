package at.jku.cp.ai.utils;

public class Constants {
	public static String ASSET_PATH = "assets";
	public static int NUMBER_OF_LEVELS = 100;
	
	private Constants()
	{
	}
}
